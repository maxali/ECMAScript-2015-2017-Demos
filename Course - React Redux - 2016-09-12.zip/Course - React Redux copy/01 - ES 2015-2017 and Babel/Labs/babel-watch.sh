#!/bin/bash
./node_modules/.bin/babel test-src.js --presets es2015 --watch --out-file test.js