"use strict";

class Child extends React.Component {
  render() {
    return (
      <h1 onClick={this.props.onClick}>I was clicked {this.props.count} times.</h1>
      );
  }
};
Child.defaultProps = { count: 0 };

class Parent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {count: 0};
    this.onClick = this.onClick.bind(this);
  }
  onClick() {
    this.setState({count: this.state.count + 1});
  }
  render() {
    return (
      <Child onClick={this.onClick} count={this.state.count} />
      );
  }
};

ReactDOM.render(
  <Parent />,
  document.getElementById('app')
  );
