"use strict";

class Child extends React.Component {
  render() {
    return (
      <h1 onClick={this.props.onClick}>I was clicked {this.props.count} times.</h1>
      );
  }
};

class Parent extends React.Component {
  render() {
    return (
      <Child />
      );
  }
};

ReactDOM.render(
  <Parent />,
  document.getElementById('app')
  );
