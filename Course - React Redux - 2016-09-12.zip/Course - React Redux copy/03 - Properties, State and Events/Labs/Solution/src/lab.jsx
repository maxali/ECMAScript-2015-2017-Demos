/// Lab: Properties, State and Events ///

const Language = {
  Danish: 'dk',
  Lithuanian: 'lt',
  Norwegian: "no",
  Dutch: "nl"
}

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { language: Language.Norwegian };

    this.handleToggleLanguageClick = this.handleToggleLanguageClick.bind(this);
  }
  
  handleToggleLanguageClick(e) {
    if (this.state.language === Language.Norwegian)
      this.setState({ language: Language.Dutch })
    else
      this.setState({ language: Language.Norwegian });
  }
  
  render() {
    return (
      <div>
        <h1>Translation</h1>
        <ul>{
          this.state.language === Language.Norwegian ?
            this.props.words.map(word => <li key={word.id}><b>{word.no}</b> - {word.nl}</li>)
          :
            this.props.words.map(word => <li key={word.id}><b>{word.nl}</b> - {word.no}</li>)
          }
        </ul>
        <div>
          <button onClick={this.handleToggleLanguageClick}>Toggle language</button>
        </div>
      </div>);
  }
}

const translations = [
  {id: 1, dk: "hej", lt: "sveiki", no: "hallo", nl: "hallo"},
  {id: 2, dk: "god morgen", lt: "labas rytas", no: "god morgen", nl: "goede morgen"},
  {id: 3, dk: "god eftermiddag", lt: "laba diena", no: "god ettermiddag", nl: "goede middag"},
  {id: 4, dk: "god aften", lt: "labas vakaras", no: "god kveld", nl: "goede avond"},
  {id: 5, dk: "kvinder", lt: "moterys", no: "kvinne", nl: "vrouw"},
  {id: 6, dk: "mand", lt: "vyras", no: "mann", nl: "man"},
  {id: 7, dk: "pige", lt: "mergina", no: "pike", nl: "meisje"},
  {id: 8, dk: "dreng", lt: "berniukas", no: "gutt", nl: "jongen"},
  {id: 9, dk: "skole", lt: "mokykla", no: "skole", nl: "school"},
];

ReactDOM.render(
  <App words={translations} />, 
  document.getElementById('app'))